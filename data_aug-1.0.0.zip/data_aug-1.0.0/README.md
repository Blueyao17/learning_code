# Data Augmentation

## Dependencies

- python3.7
- numpy
- matplotlib
- opencv-python
- yaml

## data-aug

批量图片增广和相应的xml坐标修改
***
内容为旋转、平移、镜像
***
通过仿射变换，M矩阵使用的数学原理方法
***
aug_oop中注释了M矩阵通过cv库实现的方法

## how to use

aug_oop可直接单独运行来进行数据增广，参数需要在程序中修改。
***
其他py为模块化编程，其中run.py可一块运行class_imgAu和class_xmlAug，也可在对应py单独运行。
***
参数可以通过argparse在命令行修改，默认使用yaml中的参数。
***
class_Visual 为统计增强的数目