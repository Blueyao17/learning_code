import cv2 as cv
import os
import numpy as np
import class_visual as visual
import arg_set as arg


class ImgAug(visual.Visual):     # 使用的数学化方法; 仅有平移，旋转，镜像翻转。 另：色彩变换，加噪声一般无需修改xml坐标
	def __init__(self, x, y, n, img_c):
		super().__init__()
		self.x = x
		self.y = y
		self.n = n
		self.img_c = img_c

	def img_operate(self):
		file_path = r'F:/Datasets/archive/Val/JPEGImages/'  # 需增强图片的路径
		out_path = r'F:/Datasets/archive/Val/JPEG/'			# 增强后保存的路径
		for img_name in os.listdir(file_path):
			# filename = img_name.split('.')[0]
			img_dir = file_path + img_name
			img = cv.imread(img_dir)
			self.img_translation(img, out_path, img_name, self.x, self.y)  # x=100,y=50
			self.img_tran_count += 1
			self.img_rotate(img, out_path, img_name, self.n)    # 旋转 pi/4
			self.img_rotate_count += 1
			self.img_x_flip(img, out_path, img_name)   # 左右水平镜像
			self.img_x_flip_count += 1
			self.img_y_flip(img, out_path, img_name)
			self.img_y_flip_count += 1
		img_au_total = self.img_tran_count + self.img_rotate_count + self.img_x_flip_count + self.img_y_flip_count
		print("image一共增强了%d个" % img_au_total)
		print("image平移一共增强了%d个" % self.img_tran_count)
		print("image旋转45度一共增强了%d个" % self.img_rotate_count)
		print("image左右水平镜像一共增强了%d个" % self.img_x_flip_count)
		print("image上下竖直镜像一共增强了%d个" % self.img_y_flip_count)
		self.img_chart(img_au_total, self.img_c)

	@staticmethod
	def img_translation(image, out_path, img_name, x, y):   # 平移
		h, w = image.shape[:2]
		M = np.array([[1, 0, x],
					[0, 1, y]], dtype=np.float32)
		img_tran = cv.warpAffine(image, M, (w, h))
		cv.imwrite(out_path + img_name[:-4] + '_tran.jpg', img_tran)

	@staticmethod
	def img_rotate(image, out_path, img_name, n):  # 旋转，按图片中心点的旋转
		h, w = image.shape[:2]
		angle = np.pi / n
		M = np.array([
			[np.cos(angle), np.sin(angle), (w / 2) * (1 - np.cos(angle)) - (h / 2) * np.sin(angle)],
			[-np.sin(angle), np.cos(angle), (w / 2) * np.sin(angle) + (h / 2) * (1 - np.sin(angle))]
		], dtype=np.float32)   # M矩阵也可直接使用 M = cv.getRotationMatrix2D((w/2, h/2), 45, 1)
		img_ro1 = cv.warpAffine(image, M, (w, h))
		cv.imwrite(out_path + img_name[:-4] + '_rot45.jpg', img_ro1)

	@staticmethod
	def img_x_flip(image, out_path, img_name):  # 水平镜像
		h, w = image.shape[: 2]
		Mx = np.float32([
			[-1, 0, w],
			[0, 1, 0]
		])
		img_x_fli = cv.warpAffine(image, Mx, (w, h))
		cv.imwrite(out_path + img_name[:-4] + '_X_fli.jpg', img_x_fli)
		# 图像翻转也可直接使用 flip_img = cv.flip(image,flipcode)  flipcode = 0：沿x轴翻转;flipcode > 0：沿y轴翻转;flipcode < 0：x,y轴同时翻转

	@staticmethod
	def img_y_flip(image, out_path, img_name):  # 上下竖直镜像
		h, w = image.shape[: 2]
		Mx = np.float32([
			[1, 0, 0],
			[0, -1, h]
		])  # 竖直上下镜像的 M 矩阵为  M = np.float32([[1, 0, 0], [0, -1, h]])
		img_y_fli = cv.warpAffine(image, Mx, (w, h))
		cv.imwrite(out_path + img_name[:-4] + '_y_fli.jpg', img_y_fli)


if __name__ == '__main__':
	imag = ImgAug(arg.args.x, arg.args.y, arg.args.n, arg.args.img_c)
	imag.img_operate()
