import cv2 as cv
import xml.etree.ElementTree as ET
import os
import numpy as np
import matplotlib.pyplot as plt


class Visual(object):     # 可视化统计增强的数量信息
	def __init__(self):   # 初始化计数变量
		self.img_tran_count = 0
		self.img_rotate_count = 0
		self.img_flip_count = 0
		self.xml_tran_count = 0
		self.xml_rotate_count = 0
		self.xml_flip_count = 0

	@staticmethod
	def basic(a, b, name, c):      # a 为想设置的横坐标的点的名称，b 为高度，c 为条形图颜色设置
		plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 正常显示中文
		plt.bar(range(len(a)), b, width=0.5, color=c)     # 条形图
		plt.xticks(range(len(a)), a, rotation=15)
		plt.title(name + "数据统计")
		plt.xlabel("类别")
		plt.ylabel("数量")
		plt.show()

	def img_chart(self, img_au_total):
		A = ["img_tran_count", "img_rotate_count", "img_flip_count",  "img_total"]  # 横轴每个标的名称
		B = [self.img_tran_count, self.img_rotate_count, self.img_flip_count, img_au_total]   # 对应点的高度
		self.basic(A, B, "image增强", "red")

	def xml_chart(self, xml_au_total):
		C = ["xml_tran_count", "xml_rotate_count", "xml_flip_count", "xml_total"]
		D = [self.xml_tran_count,  self.xml_rotate_count, self.xml_flip_count, xml_au_total]
		self.basic(C, D, "xml增强", "green")


class ImgAug(Visual):     # 使用的数学化方法; 仅有平移，旋转，镜像翻转。 另：色彩变换，加噪声一般无需修改xml坐标
	def img_operate(self):
		file_path = r'F:/Datasets/archive/Val/JPEGImages/'  # 需增强图片的路径
		out_path = r'F:/Datasets/archive/Val/JPEG/'			# 增强后保存的路径
		for img_name in os.listdir(file_path):
			# filename = img_name.split('.')[0]
			img_dir = file_path + img_name
			img = cv.imread(img_dir)
			self.img_translation(img, out_path, img_name, 100, 50)  # x=100,y=50
			self.img_tran_count += 1
			self.img_rotate(img, out_path, img_name, 4)    # 旋转 pi/4
			self.img_rotate_count += 1
			self.img_flip(img, out_path, img_name)   # 左右水平镜像
			self.img_flip_count += 1
		img_au_total = self.img_tran_count + self.img_rotate_count + self.img_flip_count
		print("image一共增强了%d个" % img_au_total)
		print("image平移一共增强了%d个" % self.img_tran_count)
		print("image旋转45度一共增强了%d个" % self.img_rotate_count)
		print("image左右水平镜像一共增强了%d个" % self.img_flip_count)
		self.img_chart(img_au_total)

	@staticmethod
	def img_translation(image, out_path, img_name, x, y):   # 平移
		h, w = image.shape[:2]
		M = np.array([[1, 0, x],
					[0, 1, y]], dtype=np.float32)
		img_tran = cv.warpAffine(image, M, (w, h))
		cv.imwrite(out_path + img_name[:-4] + '_tran1.jpg', img_tran)

	@staticmethod
	def img_rotate(image, out_path, img_name, n):  # 旋转，按图片中心点的旋转
		h, w = image.shape[:2]
		angle = np.pi / n
		M = np.array([
			[np.cos(angle), np.sin(angle), (w / 2) * (1 - np.cos(angle)) - (h / 2) * np.sin(angle)],
			[-np.sin(angle), np.cos(angle), (w / 2) * np.sin(angle) + (h / 2) * (1 - np.sin(angle))]
		], dtype=np.float32)   # M矩阵也可直接使用 M = cv.getRotationMatrix2D((w/2, h/2), 45, 1)
		img_ro1 = cv.warpAffine(image, M, (w, h))
		cv.imwrite(out_path + img_name[:-4] + '_xr45.jpg', img_ro1)

	@staticmethod
	def img_flip(image, out_path, img_name):  # 水平镜像
		h, w = image.shape[: 2]
		Mx = np.float32([
			[-1, 0, w],
			[0, 1, 0]
		])    # 竖直上下镜像的 M 矩阵为  M = np.float32([[1, 0, 0], [0, -1, h]])
		img_x_fli = cv.warpAffine(image, Mx, (w, h))
		cv.imwrite(out_path + img_name[:-4] + '_fli.jpg', img_x_fli)
		# 图像翻转也可直接使用 flip_img = cv.flip(image,flipcode)  flipcode = 0：沿x轴翻转;flipcode > 0：沿y轴翻转;flipcode < 0：x,y轴同时翻转


class XmlAug(Visual):
	def xml_operate(self):
		xml_path = r'F:/Datasets/archive/Val/Annotations/'    # 需修改对应 xml 的路径
		save_xml = r'F:/Datasets/archive/Val/Anno/'			  # 修改的xml保存的路径
		for xm_l in os.listdir(xml_path):
			xml_name = xm_l.split('.')[0]
			# xml_dir = xml_path + xml_name
			xml = xml_path + xml_name + '.xml'
			self.xml_parse(xml)
			self.xml_translation(xml, save_xml, xml_name, 100, 50)
			self.xml_tran_count += 1
			self.xml_rotate(xml, save_xml, xml_name, 4)
			self.xml_rotate_count += 1
			self.xml_flip(xml, save_xml, xml_name)
			self.xml_flip_count += 1
		xml_au_total = self.xml_tran_count + self.xml_rotate_count + self.xml_flip_count
		print("xml增强了%d个" % xml_au_total)
		print("xml平移增强了%d个" % self.xml_tran_count)
		print("xml旋转45度增强了%d个" % self.xml_rotate_count)
		print("xml左右水平镜像增强了%d个" % self.xml_flip_count)
		self.xml_chart(xml_au_total)

	@staticmethod
	def xml_parse(xml):
		etree = ET.parse(xml)
		root = etree.getroot()
		return etree, root

	def xml_translation(self, xml, save_xml, xml_name, x, y):  # 平移对应 xml 修改
		tree, root = self.xml_parse(xml)
		for elem in root.iter('bndbox'):
			xmin = int(elem.find('xmin').text) + int(x)
			ymin = int(elem.find('ymin').text) + int(y)
			xmax = int(elem.find('xmax').text) + int(x)
			ymax = int(elem.find('ymax').text) + int(y)
			elem.find("xmin").text = str(int(xmin))
			elem.find("ymin").text = str(int(ymin))
			elem.find("xmax").text = str(int(xmax))
			elem.find("ymax").text = str(int(ymax))
		root.find("filename").text = xml_name + '_tran1.xml'
		tree.write(os.path.join(save_xml, xml_name + '_tran1.xml'))

	def xml_rotate(self, xml, save_xml, xml_name, n):  # 旋转对应 xml 修改
		tree, root = self.xml_parse(xml)
		size = root.find('size')
		w = int(size.find('width').text)
		h = int(size.find('height').text)
		angle = np.pi / n
		for elem in root.iter('bndbox'):  # 旋转，按图片中心点旋转
			xmin = int(elem.find('xmin').text) * np.cos(angle) + int(elem.find('ymin').text) * np.sin(angle) + (
					w / 2) * (1 - np.cos(angle)) - (h / 2) * np.sin(angle)
			ymin = -int(elem.find('xmin').text) * np.sin(angle) + int(elem.find('ymin').text) * np.cos(angle) + (
					w / 2) * np.sin(angle) + (h / 2) * (1 - np.sin(angle))
			xmax = int(elem.find('xmax').text) * np.cos(angle) + int(elem.find('ymax').text) * np.sin(angle) + (
					w / 2) * (1 - np.cos(angle)) - (h / 2) * np.sin(angle)
			ymax = -int(elem.find('xmax').text) * np.sin(angle) + int(elem.find('ymax').text) * np.cos(angle) + (
					w / 2) * np.sin(angle) + (h / 2) * (1 - np.sin(angle))
			elem.find("xmin").text = str(int(xmin))
			elem.find("ymin").text = str(int(ymin))
			elem.find("xmax").text = str(int(xmax))
			elem.find("ymax").text = str(int(ymax))
		root.find("filename").text = xml_name + '_xr45.xml'
		tree.write(os.path.join(save_xml, xml_name + '_xr45.xml'))

	def xml_flip(self, xml, save_xml, xml_name):  # 左右水平镜像 xml 修改
		tree, root = self.xml_parse(xml)
		size = root.find('size')
		w = int(size.find('width').text)                   # h = int(size.find('height').text)
		for elem in root.iter('bndbox'):                   # 竖直上下镜像翻转对应的 xml 操作如下注释
			xmin = w - int(elem.find('xmax').text)         # ymin = h - int(elem.find('ymax').text)
			xmax = w - int(elem.find('xmin').text)		   # ymax = h - int(elem.find('ymin').text)
			elem.find("xmin").text = str(int(xmin))
			elem.find("xmax").text = str(int(xmax))
		root.find("filename").text = xml_name + '_fli.xml'
		tree.write(os.path.join(save_xml, xml_name + '_fli.xml'))


if __name__ == '__main__':
	imag = ImgAug()
	imag.img_operate()
	xm = XmlAug()
	xm.xml_operate()
