import matplotlib.pyplot as plt


class Visual(object):     # 可视化统计增强的数量信息
	def __init__(self):   # 初始化计数变量
		self.img_tran_count = 0
		self.img_rotate_count = 0
		self.img_x_flip_count = 0
		self.img_y_flip_count = 0
		self.xml_tran_count = 0
		self.xml_rotate_count = 0
		self.xml_x_flip_count = 0
		self.xml_y_flip_count = 0

	@staticmethod
	def basic(a, b, name, c):      # a 为想设置的横坐标的点的名称，b 为高度，c 为条形图颜色设置
		plt.rcParams['font.sans-serif'] = ['Microsoft YaHei']  # 正常显示中文
		plt.bar(range(len(a)), b, width=0.5, color=c)     # 条形图
		plt.xticks(range(len(a)), a, rotation=15)
		plt.title(name + "数据统计")
		plt.xlabel("类别")
		plt.ylabel("数量")
		plt.show()

	def img_chart(self, img_au_total, img_c):
		__A = ["img_tran_count", "img_rotate_count", "img_x_flip_count",  "img_y_flip_count", "img_total"]  # 横轴每个标的名称
		__B = [self.img_tran_count, self.img_rotate_count, self.img_x_flip_count, self.img_y_flip_count, img_au_total]
		self.basic(__A, __B, "image增强", img_c)

	def xml_chart(self, xml_au_total, xml_c):
		__C = ["xml_tran_count", "xml_rotate_count", "xml_x_flip_count", "xml_y_flip_count", "xml_total"]
		__D = [self.xml_tran_count,  self.xml_rotate_count, self.xml_x_flip_count, self.xml_x_flip_count, xml_au_total]
		self.basic(__C, __D, "xml增强", xml_c)
