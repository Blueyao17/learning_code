import class_visual
import xml.etree.ElementTree as ET
import os
import numpy as np
import arg_set as arg


class XmlAug(class_visual.Visual):
	def __init__(self, x, y, n, xml_c):
		super().__init__()
		self.x = x
		self.y = y
		self.n = n
		self.xml_c = xml_c

	def xml_operate(self):
		xml_path = r'F:/Datasets/archive/Val/Annotations/'    # 需修改对应 xml 的路径
		save_xml = r'F:/Datasets/archive/Val/Anno/'			  # 修改的xml保存的路径
		for xm_l in os.listdir(xml_path):
			xml_name = xm_l.split('.')[0]
			# xml_dir = xml_path + xml_name
			xml = xml_path + xml_name + '.xml'
			self.xml_parse(xml)
			self.xml_translation(xml, save_xml, xml_name, self.x, self.y)
			self.xml_tran_count += 1
			self.xml_rotate(xml, save_xml, xml_name, self.n)
			self.xml_rotate_count += 1
			self.xml_x_flip(xml, save_xml, xml_name)
			self.xml_x_flip_count += 1
			self.xml_y_flip(xml, save_xml, xml_name)
			self.xml_y_flip_count += 1
		xml_au_total = self.xml_tran_count + self.xml_rotate_count + self.xml_x_flip_count + self.xml_y_flip_count
		print("xml增强了%d个" % xml_au_total)
		print("xml平移增强了%d个" % self.xml_tran_count)
		print("xml旋转45度增强了%d个" % self.xml_rotate_count)
		print("xml左右水平镜像增强了%d个" % self.xml_x_flip_count)
		print("xml上下竖直镜像增强了%d个" % self.xml_y_flip_count)
		self.xml_chart(xml_au_total, self.xml_c)

	@staticmethod
	def xml_parse(xml):
		etree = ET.parse(xml)
		root = etree.getroot()
		return etree, root

	def xml_translation(self, xml, save_xml, xml_name, x, y):  # 平移对应 xml 修改
		tree, root = self.xml_parse(xml)
		for elem in root.iter('bndbox'):
			xmin = int(elem.find('xmin').text) + int(x)
			ymin = int(elem.find('ymin').text) + int(y)
			xmax = int(elem.find('xmax').text) + int(x)
			ymax = int(elem.find('ymax').text) + int(y)
			elem.find("xmin").text = str(int(xmin))
			elem.find("ymin").text = str(int(ymin))
			elem.find("xmax").text = str(int(xmax))
			elem.find("ymax").text = str(int(ymax))
		root.find("filename").text = xml_name + '_tran.xml'
		tree.write(os.path.join(save_xml, xml_name + '_tran.xml'))

	def xml_rotate(self, xml, save_xml, xml_name, n):  # 旋转对应 xml 修改
		tree, root = self.xml_parse(xml)
		size = root.find('size')
		w = int(size.find('width').text)
		h = int(size.find('height').text)
		angle = np.pi / n
		for elem in root.iter('bndbox'):  # 旋转，按图片中心点旋转
			xmin = int(elem.find('xmin').text) * np.cos(angle) + int(elem.find('ymin').text) * np.sin(angle) + (
					w / 2) * (1 - np.cos(angle)) - (h / 2) * np.sin(angle)
			ymin = -int(elem.find('xmin').text) * np.sin(angle) + int(elem.find('ymin').text) * np.cos(angle) + (
					w / 2) * np.sin(angle) + (h / 2) * (1 - np.sin(angle))
			xmax = int(elem.find('xmax').text) * np.cos(angle) + int(elem.find('ymax').text) * np.sin(angle) + (
					w / 2) * (1 - np.cos(angle)) - (h / 2) * np.sin(angle)
			ymax = -int(elem.find('xmax').text) * np.sin(angle) + int(elem.find('ymax').text) * np.cos(angle) + (
					w / 2) * np.sin(angle) + (h / 2) * (1 - np.sin(angle))
			elem.find("xmin").text = str(int(xmin))
			elem.find("ymin").text = str(int(ymin))
			elem.find("xmax").text = str(int(xmax))
			elem.find("ymax").text = str(int(ymax))
		root.find("filename").text = xml_name + '_rot45.xml'
		tree.write(os.path.join(save_xml, xml_name + '_rot45.xml'))

	def xml_x_flip(self, xml, save_xml, xml_name):  # 左右水平镜像 xml 修改
		tree, root = self.xml_parse(xml)
		size = root.find('size')
		w = int(size.find('width').text)
		for elem in root.iter('bndbox'):
			xmin = w - int(elem.find('xmax').text)
			xmax = w - int(elem.find('xmin').text)
			elem.find("xmin").text = str(int(xmin))
			elem.find("xmax").text = str(int(xmax))
		root.find("filename").text = xml_name + '_x_fli.xml'
		tree.write(os.path.join(save_xml, xml_name + '_x_fli.xml'))

	def xml_y_flip(self, xml, save_xml, xml_name):   # 上下竖直镜像xml修改坐标
		tree, root = self.xml_parse(xml)
		size = root.find('size')
		h = int(size.find('height').text)
		for elem in root.iter('bndbox'):
			ymin = h - int(elem.find('ymax').text)
			ymax = h - int(elem.find('ymin').text)
			elem.find("ymin").text = str(int(ymin))
			elem.find("ymax").text = str(int(ymax))
		root.find("filename").text = xml_name + '_y_fli.xml'
		tree.write(os.path.join(save_xml, xml_name + '_y_fli.xml'))


if __name__ == '__main__':
	xm = XmlAug(arg.args.x, arg.args.y, arg.args.n, arg.args.xml_c)
	xm.xml_operate()
