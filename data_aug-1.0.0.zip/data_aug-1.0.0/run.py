import class_imgAu as imgAu
import class_xmlAu as xmlAu
import arg_set as arg


if __name__ == '__main__':   # class_imgAu.py 和 class_xmlAu 都可单独运行，此处为一块运行
	imag = imgAu.ImgAug(arg.args.x, arg.args.y, arg.args.n, arg.args.img_c)
	imag.img_operate()
	xm = xmlAu.XmlAug(arg.args.x, arg.args.y, arg.args.n, arg.args.xml_c)
	xm.xml_operate()
