from setuptools import setup


setup(
	name="data_aug",
	version="1.0.0",
	url=" ",
	author="Blue_yao",
	description="Enlarge the image and modify the coordinates of the corresponding XML",
	py_modules=['aug_oop', "run", 'config', "arg_set", "class_imgAu", "class_xmlAu", "class_visual", 'README'],
	install_requires=[
		'numpy',
		'opencv-python',
		'yaml',
		'matplotlib'
	])
