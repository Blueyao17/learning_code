import yaml
import argparse


def read_yaml():
	with open("config.yaml", encoding="utf-8") as f:
		config_ = yaml.load(f.read(), Loader=yaml.FullLoader)
		print(config_)
		print("yaml中x为%d" % config_['x'])
		print("yaml中y为%d" % config_['y'])
		print("yaml中n为%d" % config_['n'])
		print("yaml中img_c为%s" % config_['img_c'])
		print("yaml中xml_c为%s" % config_['xml_c'])
		return config_


config = read_yaml()
parser = argparse.ArgumentParser(description="some parameters")
parser.add_argument('--x', type=int, default=config['x'], help="translation's x")
parser.add_argument('--y', type=int, default=config['y'], help="translation's y")
parser.add_argument('--n', type=int, default=config['n'], help="rotation's n (pi/n)")
parser.add_argument('--img_c', type=str, default=config['img_c'], help="color of image's bar")
parser.add_argument('--xml_c', type=str, default=config['xml_c'], help="color of xml's bar")
args = parser.parse_args()
